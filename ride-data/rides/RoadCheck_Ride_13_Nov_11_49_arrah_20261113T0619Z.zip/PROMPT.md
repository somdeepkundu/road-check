# Task: analyse one road-roughness ride logged by a phone

You are helping a researcher (Somdeep Kundu, RuDRA Lab, C-TARA, IIT Bombay) understand the condition of the roads on one ride.
The attached files are the output of the Road Check web app. Read this whole brief first, then the files, then work through the plan.

## This ride
- Name: Ride 13 Nov 11:49 arrah · vehicle: motorbike · phone: pocket or bag
- Time (UTC): 2026-11-13T06:19:53.358Z to 2026-11-13T06:23:23.973Z · local time = UTC+05:30
- Scored distance 740 m of 788 m in 40 stretches; sharp bumps 101; mean index 4.87
- Share of distance: smooth 0% · fair 0% · rough 43% · very rough 51% · not scored 6%
- Area: bounding box south,west,north,east = 23.50002,86.69591,23.50379,86.70202
- Gyroscope: yes · GPS speed from phone: yes
- Logging pauses (screen off / app in background): 0
- Raw readings: 12639 rows; all kept except time standing still

Roughest stretches (full list is in the CSV):

| seg | class | index | km/h | bumps | lat, lon (middle) |
|---|---|---|---|---|---|
| 28 | very rough | 13.63 | 11 | 2 | 23.50200, 86.70088 |
| 4 | very rough | 11.09 | 13 | 6 | 23.50333, 86.69661 |
| 1 | very rough | 10.40 | 13 | 5 | 23.50288, 86.69636 |
| 7 | very rough | 9.54 | 13 | 2 | 23.50338, 86.69710 |
| 8 | very rough | 9.51 | 14 | 3 | 23.50330, 86.69725 |

## Files
- `data/Ride_13_Nov_11_49_arrah_segments.csv` — the main table, one row per 20 m of travel. **Column meanings, units and what an empty cell means are in `datapackage.json`** (read it; do not guess).
- `data/Ride_13_Nov_11_49_arrah_segments.geojson` — same stretches as lines. `data/Ride_13_Nov_11_49_arrah_bumps.geojson` — one point per sharp hit.
- `raw/Ride_13_Nov_11_49_arrah_raw.csv` — every motion reading, for checking a stretch in detail.
- `ride.json` — settings, device facts, pauses, summary. `README.txt` — the same field notes in plain text.

## How to read the numbers (do not skip)
1. **An empty cell means "not measured", never zero.** An empty `index`/`class` means the stretch could not be scored (too slow, too few readings), not that the road is smooth. Do not fill or average over them as if they were 0.
2. **`index` is not calibrated.** It is `rms_v × (30 km/h ÷ speed)^1`, with class breaks at 1, 2, 3.5. These are starting guesses. Use it to rank stretches **within this ride** (or with rides on the same vehicle, tyres and mount), not as an absolute standard such as IRI. If you want an absolute scale, say what reference data you would need.
3. **Shake depends on speed.** The speed adjustment (exponent 1) is a first guess. Check it (plan step 3d) before trusting comparisons between fast and slow stretches.
4. **Mount matters:** "pocket or bag". A pocket or bag damps the shake and hides small defects; a handlebar mount sees what the frame sees.
5. **Positions:** stretches follow the GPS track (± `gps_acc_max_m`). A bump's position is good to about one second of travel (about 10 m at 36 km/h). Do not claim a pothole is "at" a coordinate more precisely than that.
6. **Sharp bumps are not all defects.** Speed breakers, rumble strips, level crossings, expansion joints and manhole covers also produce them. Decide which with evidence (plan step 2), not by size alone.
7. Express uncertainty. With under about 5 stretches in a group, say the group is too small to compare.

## Plan
**1. Check the data first.** Confirm rate_hz is near 60 on scored stretches; list stretches with flags (slow, low_rate, gps_weak, gps_gap, partial) and the pauses; say how much of the ride is usable. Stop and report if less than half is scored.

**2. Enrich with outside information, if you have internet or API tools.** Do this agentically: fetch what you can, record each source and the query, and skip (and say you skipped) what you cannot reach. Do not invent values.
- *Road type and surface (OpenStreetMap, Overpass API).* Query the bounding box above, e.g.
  `[out:json][timeout:60];way["highway"](23.50002,86.69591,23.50379,86.70202);out tags geom;`
  Keep `highway`, `surface`, `smoothness`, `maxspeed`, `lanes`, `bridge`, `tunnel`, `layer`, `name`, `ref`.
  Match each stretch to a way: nearest way within 15 m of the stretch's middle whose direction is within 30° of `heading_deg` (either way along the road). If two ways qualify within 5 m of each other (parallel carriageways, a flyover over a road), mark the stretch **ambiguous** rather than guessing. Many roads have no `surface` tag: report "untagged", do not assume.
- *Features that explain bumps (same API).* `node["traffic_calming"](bbox); node["railway"="level_crossing"](bbox); node["highway"~"traffic_signals|crossing"](bbox);` and ways with `bridge=yes`. A sharp bump within 15 m of one of these is "probably designed or structural"; the rest are "unexplained", the candidates for defects.
- *Place names.* Reverse-geocode the start, end and the roughest stretches (OpenStreetMap Nominatim: one request per second, identify yourself in the User-Agent) so findings can be written as "on X Road near Y".
- *Weather.* Hourly rain for the ride day and the 24 h before (for example Open-Meteo archive: `https://archive-api.open-meteo.com/v1/archive` with latitude, longitude, the dates, `hourly=precipitation`, `timezone=auto`). Wet roads hide or exaggerate defects and monsoon damage is real; mention it if it rained.
- *Anything else you can find that is relevant* (a ward or municipal road register, recent resurfacing news, traffic volume). Cite it.
Write the enriched table as **new files** (for example `segments_enriched.csv` and `.geojson` with columns such as `osm_highway`, `osm_surface`, `osm_smoothness`, `osm_name`, `match_quality`, `near_feature`). Leave the original files unchanged.

**3. Analyse.**
 a. Roughness by road type and by surface: distance-weighted mean index, share per class, number of stretches. Mark groups with < 5 stretches as low confidence.
 b. Compare what you measured with the OSM `surface` / `smoothness` tags: list disagreements both ways (tagged "asphalt" but very rough; tagged "bad" but smooth). The map may be out of date; say so rather than declaring either wrong.
 c. Bumps: split into explained (near a speed breaker, crossing, joint) and unexplained; rank the unexplained by `peak_v` and check each in the raw file (a real pothole is a short sharp event followed by ringing; a long rough patch is texture).
 d. Check the speed adjustment: within one road type, regress log(rms_v) on log(speed_kmh) for scored and slow stretches alike. The slope is the speed exponent the data suggest (the app assumes 1). If it is clearly different, recompute the index with it, report both, and do not overwrite the original.
 e. Curves: are rough stretches mostly on bends (high `rms_lateral`, small `curve_radius_*`)? If so, lean may be inflating the shake there.
 f. Bump count sanity: if there are more than about 50 bumps per km, the 4 m/s² threshold is catching texture or body motion, not single defects. Re-detect with a threshold relative to the ride (for example 4 × the median `rms_v`) and report both counts.
 g. Anything surprising: a stretch that is very rough on an otherwise smooth road is the most useful finding.

**4. Deliver.**
 - A short written summary (under 300 words) for a non-expert: how good or bad was this route, where, and what to look at first.
 - A ranked list of the 10 stretches most worth inspecting: coordinates, road name and type, index, speed, bumps, your evidence, and a confidence (high / medium / low).
 - A table by road type and surface, and a map (or GeoJSON ready for QGIS) coloured by class.
 - **A one-page report poster** (`road_report_poster.png` at 200 dpi, plus a PDF), made in Python with **seaborn** on matplotlib (`sns.set_theme(style="whitegrid", context="talk")`). Panels:
   1. a title strip: ride name, date, place, vehicle, mount, distance, moving time, and a one-line verdict;
   2. a map of the route (stretch lines in lon/lat, aspect corrected by cos(lat)) coloured by `rms_v` with a colourbar, the 5 roughest stretches labelled 1–5, start and end marked, on a faint OpenStreetMap basemap (`contextily.add_basemap(ax, crs="EPSG:4326", source=cx.providers.OpenStreetMap.Mapnik, alpha=0.35, zorder=0)`, credit "© OpenStreetMap contributors" on the map). If the tiles cannot be fetched, draw without them and write "no basemap" in the panel title;
   3. `rms_v` and speed along the ride (x = distance in km);
   4. log(rms_v) against log(speed) with `sns.regplot`, the fitted slope printed (check 3d);
   5. distance share per class as a horizontal bar, or per road type once enriched;
   6. the vertical-shake spectrum from the raw file (Welch), to show where the energy is (road texture is mostly above about 10 Hz, rider and pocket motion below);
   7. a small table of the top 5 stretches, and a footer with caveats and sources.
   Use one colour ramp for roughness everywhere, readable labels, no chart junk. Open the image and check every panel before handing it over.
 - "What I could not do and why", and "what extra data would make this stronger" (for example the same road ridden twice, a second vehicle, a few photographed defects to calibrate against).

## Rules
- Use only the data here and sources you actually fetched. Never fabricate a coordinate, a road name or a measurement.
- Keep units: m/s², km/h, m. Report numbers with sensible rounding.
- Quote the file and column behind every number you rely on.
- If the ride is simulated or the mount is a pocket, say how that limits the conclusions.

## My question (edit before sending)
Give me the full analysis above for this ride. Then tell me what I should do on my next ride to make the data better.
