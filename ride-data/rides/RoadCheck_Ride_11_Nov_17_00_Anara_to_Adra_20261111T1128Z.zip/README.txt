Road Check 0.2.0 — Ride 11 Nov 17:00 Anara to Adra
Vehicle: motorbike. Phone: handlebar mount.
To analyse this ride with an LLM: attach everything in this ZIP and paste PROMPT.md (or just upload the ZIP and say "follow PROMPT.md").
954 stretches, 137228 raw readings.

data/*_segments.geojson, *_segments.csv — one row per stretch of road (20 m of travel).
  class               smooth | fair | rough | very rough; empty when the stretch could not be scored
  index               rms_v x (30 km/h / speed)^1. Breaks at 1, 2, 3.5. NOT CALIBRATED: starting values.
  rms_v, peak_v       up-down shake in m/s2 (gravity removed, any phone pose): root-mean-square and largest
  bumps               sharp hits above 4 m/s2 in the stretch
  speed_kmh           length / moving time; speed_source says whether the phone gave GPS speed or it came from fixes
  rms_lateral         shake across the vertical, m/s2
  heading_deg         direction of travel; turn_deg is the change from the previous stretch (+ = right)
  curve_radius_gps_m  from that change; noisy at 20 m. curve_radius_gyro_m = speed / turn rate, better when there is a gyroscope
  turn_rate_dps       mean gyroscope turn about the vertical, deg/s (reads about cos(lean) low on a leaning bike)
  rate_hz, max_gap_ms how many readings per second, and the longest silence between two readings
  flags               slow (< 10 km/h, not scored), low_rate, gps_weak (worse than 15 m), gps_gap, partial

data/*_bumps.geojson — one point per sharp hit, placed along the line between two GPS fixes (good to about one second of travel).

raw/*_raw.csv — every reading. time_unix_ms; ax, ay, az = acceleration including gravity in the phone's axes, m/s2;
  rot_* = gyroscope deg/s (blank without one); vertical = up-down shake used for the scores (blank while the gravity average settles).
  All of the ride was kept, except time spent standing.

ride.json — settings, device and the pauses when the screen was off (nothing is logged then).
Compare roads only between rides on the same vehicle, tyre pressure and mount.
Somdeep Kundu, RuDRA Lab, C-TARA, IIT Bombay
